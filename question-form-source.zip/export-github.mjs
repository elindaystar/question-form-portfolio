// Produce a portable, dependency-free static copy for GitHub's browser uploader.
import fs from 'node:fs';
import path from 'node:path';
const output=path.resolve('../question-form-github-upload');
fs.mkdirSync(output,{recursive:true});
const css=fs.readFileSync('dist/css/editorial.css','utf8');
const scripts=['motion','cursor','project-filter','editorial'].map(name=>fs.readFileSync(`dist/js/${name}.js`,'utf8').replace(/^import .*;\r?\n/gm,'').replaceAll('export function ','function ')).join('\n');
for(const file of fs.readdirSync('dist').filter(f=>f.endsWith('.html'))){let html=fs.readFileSync('dist/'+file,'utf8');html=html.replace('<link rel="stylesheet" href="css/editorial.css">',`<style>${css}</style>`).replace('<script type="module" src="js/editorial.js"></script>',`<script type="module">${scripts}</script>`);fs.writeFileSync(path.join(output,file),html);}
fs.writeFileSync(path.join(output,'README.md'),fs.readFileSync('README.md','utf8')+'\n\n## GitHub 배포본\n\n이 저장소의 루트 HTML은 CSS·JavaScript를 포함한 독립 실행형 정적 배포본입니다. PHP 원본과 콘텐츠 데이터는 [question-form-source.zip](question-form-source.zip)에 포함되어 있습니다. 원본에서 `node generate.mjs`로 다시 내보낼 수 있습니다.\n');
fs.writeFileSync(path.join(output,'.nojekyll'),'');
console.log(output);
