import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
const php=process.env.PHP_BINARY||'C:/xampp/php/php.exe';
function render(file,id=''){const script=`define('STATIC_EXPORT',true); $_GET['id']='${id}'; include '${file}.php';`;return execFileSync(php,['-d','display_errors=stderr','-r',script],{encoding:'utf8'});}
for(const name of ['index','projects'])fs.writeFileSync(`dist/${name}.html`,render(name));
for(const id of ['project01','project02','project03'])fs.writeFileSync(`dist/project-${id}.html`,render('project',id));
let router=render('project').replace('data-page="detail"','data-page="detail-router"');
router=router.replace('</section>','<noscript><p>아래 링크에서 프로젝트를 선택해 주세요.</p></noscript><div class="router-links"><a href="project-project01.html">UI / UX ↗</a> · <a href="project-project02.html">BRANDING ↗</a> · <a href="project-project03.html">GRAPHIC ↗</a></div></section>');
fs.writeFileSync('dist/project.html',router);
fs.writeFileSync('dist/404.html',render('project'));
for(const [file,target]of [['about.html','index.html#about'],['contact.html','index.html#contact'],['sitemap.html','index.html']])fs.writeFileSync('dist/'+file,`<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url=${target}"><title>QUESTION / FORM</title></head><body><a href="${target}">이동하기</a></body></html>`);
fs.writeFileSync('dist/project-detail.html',router);
console.log('Exported PHP templates to public static pages.');
