<?php
$profile = ['name' => 'QUESTION / FORM', 'email' => '', 'github' => 'https://github.com/elindaystar'];
// 실제 프로젝트 자료를 받은 뒤 이 배열을 교체합니다. 현재 항목은 구성 예시입니다.
$projects = [
 'project01' => ['title'=>'명확한 흐름을 만드는 일', 'category'=>'UI / UX', 'filter'=>'uiux', 'number'=>'01', 'theme'=>'interface', 'visual'=>'Less, but clear.', 'description'=>'정보와 행동의 순서를 설계하는 작업을 소개할 자리입니다.', 'question'=>'복잡한 정보를 어떻게 쉽게 이해하게 할까?', 'interpret'=>'사용자의 상황, 관찰한 문제, 핵심 인사이트를 실제 프로젝트 자료와 함께 정리할 예정입니다.', 'form'=>'화면 구조, 정보의 우선순위, 주요 인터랙션을 이곳에 소개합니다.'],
 'project02' => ['title'=>'관계에서 시작하는 형태', 'category'=>'BRANDING', 'filter'=>'branding', 'number'=>'02', 'theme'=>'identity', 'visual'=>'in between', 'description'=>'하나의 생각을 일관된 인상으로 연결하는 작업을 소개할 자리입니다.', 'question'=>'보이지 않는 생각을 어떻게 하나의 인상으로 전할까?', 'interpret'=>'브랜드가 전하려는 가치와 디자인 방향을 실제 프로젝트의 맥락에 맞춰 정리할 예정입니다.', 'form'=>'로고, 색상, 서체와 응용 매체에 걸친 시각 언어를 이곳에 소개합니다.'],
 'project03' => ['title'=>'다르게 읽는 익숙한 것', 'category'=>'GRAPHIC', 'filter'=>'graphic', 'number'=>'03', 'theme'=>'graphic', 'visual'=>'A different point of view.', 'description'=>'글자와 여백으로 새로운 시선을 만드는 작업을 소개할 자리입니다.', 'question'=>'익숙한 정보에 새로운 시선을 만들 수 있을까?', 'interpret'=>'매체와 독자, 읽는 순서를 고려한 디자인 해석을 실제 작업과 함께 정리할 예정입니다.', 'form'=>'타이포그래피, 그리드, 크기와 여백의 관계를 이곳에 소개합니다.']
];
