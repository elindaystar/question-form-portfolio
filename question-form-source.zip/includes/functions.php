<?php
require_once __DIR__.'/project-data.php';
function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function route($page='index', $id='') { if(defined('STATIC_EXPORT') && $page==='project' && $id) return 'project-'.rawurlencode($id).'.html'; return $page.(defined('STATIC_EXPORT')?'.html':'.php').($id ? '?id='.rawurlencode($id):''); }
function visual($p) { ?>
 <div class="project-visual <?= e($p['theme']) ?>" aria-label="<?= e($p['category']) ?> 프로젝트 준비용 타이포그래피 예시"><span class="visual-meta">QUESTION / FORM — <?= e($p['number']) ?></span><span class="visual-type"><?= e($p['visual']) ?></span><span class="visual-foot">DESIGN STUDY <span>예시 비주얼</span></span></div>
<?php }
function project_card($id,$p) { ?>
 <article class="project-card" data-category="<?= e($p['filter']) ?>"><a class="project-link" data-cursor="VIEW" href="<?= route('project',$id) ?>"><div class="project-meta"><span><?= e($p['number']) ?> / <?= e($p['category']) ?></span><span>준비 중</span></div><?php visual($p); ?><div class="project-heading"><h3><?= e($p['title']) ?></h3><span aria-hidden="true">↗</span></div><p><?= e($p['description']) ?></p></a></article>
<?php }
