import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const files=fs.readdirSync('dist').filter(f=>f.endsWith('.html'));
const voids=new Set(['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']);
for(const file of files){
 const html=fs.readFileSync('dist/'+file,'utf8'),stack=[];
 for(const m of html.matchAll(/<\/?([a-z][\w-]*)\b[^>]*>/gi)){const tag=m[1].toLowerCase();if(voids.has(tag))continue;if(m[0].startsWith('</'))assert.equal(stack.pop(),tag,file);else stack.push(tag);}
 assert.equal(stack.length,0,file);
 for(const m of html.matchAll(/(?:src|href)="([^"]+)"/g)){const url=m[1];if(/^(https?:|data:|mailto:)/.test(url))continue;const [local,hash]=url.split('#'),target=local.split('?')[0]||file;assert.ok(fs.existsSync(path.join('dist',target)),`${file}: ${url}`);if(hash)assert.ok(fs.readFileSync(path.join('dist',target),'utf8').includes(`id="${hash}"`),`${file}: ${url}`);}
 assert.ok(!/PHP (?:Warning|Fatal)|<\?php/.test(html),file);
}
const home=fs.readFileSync('dist/index.html','utf8');
for(const text of ['저는 먼저 묻습니다.','이해시켜야 할까?','형태로 답합니다.','DESIGN ATTITUDE'])assert.ok(home.includes(text),text);
assert.ok(!/Skills & Tools|SKILLS & TOOLS|THE PROCESS/.test(home));
for(const id of ['project01','project02','project03']){const html=fs.readFileSync(`dist/project-${id}.html`,'utf8');for(const stage of ['OVERVIEW','QUESTION','INTERPRET','FORM','RESULT','NEXT PROJECT'])assert.ok(html.includes(stage),id+stage);assert.ok(html.includes('구성 예시'));}
console.log(`PASS: ${files.length} HTML pages, local links/anchors, required copy, project stories, no PHP errors.`);
