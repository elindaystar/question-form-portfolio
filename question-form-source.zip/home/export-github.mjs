import fs from 'node:fs';
import path from 'node:path';
const output=path.resolve('.release/github');
fs.mkdirSync(output,{recursive:true});
const css=fs.readFileSync('dist/css/editorial.css','utf8');
const scripts=['motion','cursor','project-filter','editorial'].map(name=>fs.readFileSync(`dist/js/${name}.js`,'utf8').replace(/^import .*;\r?\n/gm,'').replaceAll('export function ','function ')).join('\n');
for(const file of fs.readdirSync('dist').filter(f=>f.endsWith('.html'))){let html=fs.readFileSync('dist/'+file,'utf8');html=html.replace('<link rel="stylesheet" href="css/editorial.css">',`<style>${css}</style>`).replace('<script type="module" src="js/editorial.js"></script>',`<script type="module">${scripts}</script>`).replaceAll('assets/projects/','');fs.writeFileSync(path.join(output,file),html);}
for(const file of fs.readdirSync('dist/assets/projects'))fs.copyFileSync('dist/assets/projects/'+file,path.join(output,file));
fs.writeFileSync(path.join(output,'README.md'),fs.readFileSync('README.md','utf8')+'\n\n## GitHub 배포본\n\n저장소 루트 HTML과 WebP 파일은 바로 호스팅할 수 있는 정적 사이트입니다. 정리된 `home` 폴더의 PHP 원본은 [question-form-source.zip](question-form-source.zip)에서 내려받을 수 있습니다.\n');
fs.writeFileSync(path.join(output,'.nojekyll'),'');
console.log(output);
