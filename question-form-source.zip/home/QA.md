# 검증 기록 — 2026-09-16

- Home: About → Profile → Selected Work 순서 확인. Selected Work는 카테고리별 1개씩 총 3개.
- 윤아인 / meihaodeguanxi@gmail.com / 툴 3종 / 자격증 3종은 제공받은 값과 일치.
- Contact에 GitHub 링크 없음. 이메일 링크 정상.
- 프로젝트 6개: UI/UX 3개, Branding 2개, Graphic 1개. 브라우저 필터 결과 3/2/1/6 확인.
- 크롭 중심: Ligachembio/GST 상단 Hero, MOODLE 최상단 타이틀·밤하늘, UNSEEN 전시 포스터, 아리담 캐릭터, 라운드랩 광고.
- 6개 이미지를 원본 해상도·비율 그대로 WebP 인코딩. 상세 페이지는 전체 이미지, 썸네일은 CSS 크롭.
- 14개 정적 HTML의 구조, 링크·앵커, 이미지·alt·크기 지정, 상세 6개 및 다음 프로젝트 연결 검사 통과.
- 모든 PHP 원본과 JS 문법 검사 통과.
- 프로젝트 목록 1440/1280/1024/768/390/375px에서 가로 넘침 없음.
- Profile 데스크톱 sticky, 375px에서는 static 세로 배치 확인. 이름·메일 가독성 확인.
- 브라우저 console error/warn 없음.
- 제공되지 않은 연도·참여율·자격 취득일·성과는 표시하지 않음.
- 공개 배포 폴더: dist. PHP 실행을 위한 원본은 home 루트와 includes.
