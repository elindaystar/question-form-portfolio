import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const files=fs.readdirSync('dist').filter(f=>f.endsWith('.html'));
const voids=new Set(['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']);
for(const file of files){
 const html=fs.readFileSync('dist/'+file,'utf8'),stack=[];
 for(const m of html.matchAll(/<\/?([a-z][\w-]*)\b[^>]*>/gi)){const tag=m[1].toLowerCase();if(voids.has(tag))continue;if(m[0].startsWith('</'))assert.equal(stack.pop(),tag,file);else stack.push(tag);}
 assert.equal(stack.length,0,file);
 for(const m of html.matchAll(/(?:src|href)="([^"]+)"/g)){const url=m[1];if(/^(https?:|data:|mailto:)/.test(url))continue;const [local,hash]=url.split('#'),target=local.split('?')[0]||file;assert.ok(fs.existsSync(path.join('dist',target)),`${file}: ${url}`);if(hash)assert.ok(fs.readFileSync(path.join('dist',target),'utf8').includes(`id="${hash}"`),`${file}: ${url}`);}
 for(const img of html.matchAll(/<img\b[^>]*>/g)){assert.match(img[0],/alt="[^"]+"/);assert.match(img[0],/width="\d+"/);assert.match(img[0],/height="\d+"/);}
 assert.ok(!/PHP (?:Warning|Fatal)|<\?php/.test(html),file);
 assert.ok(!/구성 예시|등록 예정|프로젝트 준비 중|GITHUB ↗/.test(html),file);
}
const home=fs.readFileSync('dist/index.html','utf8');
assert.ok(home.indexOf('id="about"')<home.indexOf('id="profile"')&&home.indexOf('id="profile"')<home.indexOf('id="work"'));
for(const text of ['윤아인','meihaodeguanxi@gmail.com','웹디자인기능사','컴퓨터그래픽스기능사','시각디자인산업기사','Figma','Photoshop','Illustrator'])assert.ok(home.includes(text),text);
assert.ok(!/After Effects|Skills & Tools|SKILLS & TOOLS|THE PROCESS/.test(home));
for(const category of ['uiux','branding','graphic']) assert.equal((home.match(new RegExp(`data-category="${category}"`,'g'))||[]).length,1);
const expected=[['Ligachembio','UI / UX'],['GST','UI / UX'],['MOODLE','UI / UX'],['UNSEEN','BRANDING'],['아리담','BRANDING'],['라운드랩 독도','GRAPHIC']];
expected.forEach(([title,category],i)=>{const html=fs.readFileSync(`dist/project-project0${i+1}.html`,'utf8');assert.ok(html.includes(title)&&html.includes(category));for(const stage of ['OVERVIEW','QUESTION','INTERPRET','FORM','RESULT','NEXT PROJECT'])assert.ok(html.includes(stage));assert.match(html,/<figure class="full-project-image"><img/);});
const archive=fs.readFileSync('dist/projects.html','utf8');for(const [cat,count]of [['uiux',3],['branding',2],['graphic',1]])assert.equal((archive.match(new RegExp(`data-category="${cat}"`,'g'))||[]).length,count);
console.log(`PASS: ${files.length} HTML pages; profile placement and exact data; 6 project images; categories 3/2/1; local links and anchors; no placeholder or GitHub contact.`);
