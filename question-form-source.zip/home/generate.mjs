import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
const php=process.env.PHP_BINARY||(process.platform==='win32'?'C:/xampp/php/php.exe':'php');
const ids=JSON.parse(execFileSync(php,['-r',"require 'includes/project-data.php'; echo json_encode(array_keys($projects));"],{encoding:'utf8'}));
function render(file,id=''){return execFileSync(php,['-d','display_errors=stderr','-r',`define('STATIC_EXPORT',true); $_GET['id']='${id}'; include '${file}.php';`],{encoding:'utf8'});}
for(const name of ['index','projects'])fs.writeFileSync(`dist/${name}.html`,render(name));
for(const id of ids)fs.writeFileSync(`dist/project-${id}.html`,render('project',id));
let router=render('project').replace('data-page="detail"','data-page="detail-router"');
router=router.replace('</section>','<noscript><p>프로젝트 목록에서 작업을 선택해 주세요.</p></noscript></section>');
fs.writeFileSync('dist/project.html',router);
fs.writeFileSync('dist/project-detail.html',router);
fs.writeFileSync('dist/404.html',render('project'));
for(const [file,target]of [['about.html','index.html#about'],['contact.html','index.html#contact'],['sitemap.html','index.html']])fs.writeFileSync('dist/'+file,`<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url=${target}"><title>QUESTION / FORM</title></head><body><a href="${target}">이동하기</a></body></html>`);
console.log(`Exported home, profile, projects, ${ids.length} project stories, and fallback routes.`);
