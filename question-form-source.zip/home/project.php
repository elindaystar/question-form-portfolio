<?php
require_once __DIR__.'/includes/functions.php';
$id=$_GET['id']??'';
$p=is_string($id)?($projects[$id]??null):null;
$page='detail'; $title=$p?$p['title']:'프로젝트를 찾을 수 없습니다';
if(!$p) http_response_code(404);
require __DIR__.'/includes/header.php';
if(!$p): ?>
<section class="not-found section-pad"><p>404 / PROJECT NOT FOUND</p><h1>아직 도착하지 않은<br>질문입니다.</h1><a class="text-link" href="<?= route('projects') ?>">프로젝트 목록으로 ↗</a></section>
<?php else: ?>
<article class="project-detail" data-project="<?= e($id) ?>">
    <header class="detail-hero section-pad">
        <a class="back-link" href="<?= route('projects') ?>">← ALL PROJECTS</a>
        <div class="project-meta"><span><?= e($p['number']) ?> / <?= e($p['category']) ?></span><span><?= e($p['type']) ?></span></div>
        <h1><?= e($p['title']) ?><span class="blue">.</span></h1>
        <p><?= e($p['description']) ?></p>
    </header>
    <div class="detail-cover"><?php visual($p); ?></div>
    <section class="story-row section-pad"><h2>01 / OVERVIEW</h2><div><h3><?= e($p['description']) ?></h3><dl><div><dt>PROJECT</dt><dd><?= e($p['title']) ?></dd></div><div><dt>CATEGORY</dt><dd><?= e($p['category']) ?></dd></div><div><dt>FORMAT</dt><dd><?= e($p['type']) ?></dd></div></dl></div></section>
    <section class="question-story section-pad"><h2>02 / QUESTION</h2><p><?= e($p['question']) ?></p></section>
    <section class="story-row section-pad"><h2>03 / INTERPRET</h2><div><h3>질문을 바라보는 관점.</h3><p><?= e($p['interpret']) ?></p></div></section>
    <section class="story-row form-story section-pad"><h2>04 / FORM</h2><div><h3>생각에서 시각 언어로.</h3><p><?= e($p['form']) ?></p><ul class="design-focus"><?php foreach($p['focus'] as $focus): ?><li><?= e($focus) ?></li><?php endforeach; ?></ul></div></section>
    <section class="result-story section-pad">
        <div class="section-marker"><h2>05 / RESULT</h2><a class="full-image-link" href="<?= asset('assets/projects/'.$p['image'].'.webp') ?>" target="_blank" rel="noopener">크게 보기 ↗</a></div>
        <figure class="full-project-image"><img src="<?= asset('assets/projects/'.$p['image'].'.webp') ?>" alt="<?= e($p['alt']) ?> — 전체 작업 이미지" width="<?= $p['width'] ?>" height="<?= $p['height'] ?>" loading="lazy" decoding="async"><figcaption><?= e($p['title']) ?> / <?= e($p['type']) ?></figcaption></figure>
    </section>
    <?php $keys=array_keys($projects);$next=$keys[(array_search($id,$keys)+1)%count($keys)]; ?>
    <a class="next-project section-pad" href="<?= route('project',$next) ?>"><span>NEXT PROJECT / <?= e($projects[$next]['category']) ?></span><strong><?= e($projects[$next]['title']) ?> ↗</strong></a>
</article>
<?php endif; require __DIR__.'/includes/footer.php'; ?>
