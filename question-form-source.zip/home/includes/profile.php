<section id="profile" class="profile section-pad" aria-labelledby="profile-title">
    <div class="profile-heading">
        <p class="profile-index">02 / THE DESIGNER</p>
        <h2 id="profile-title">PROFILE<span class="blue">.</span></h2>
        <p class="profile-intro">질문을 던지는 사람,<br>형태를 만드는 사람.</p>
    </div>
    <div class="profile-content">
        <section class="profile-block personal" aria-labelledby="personal-title">
            <h3 id="personal-title"><span>01</span> PERSONAL</h3>
            <p class="profile-label">NAME</p><p class="profile-name"><?= e($profile['name']) ?></p>
            <p class="profile-statement"><?= e($profile['statement']) ?></p>
            <p class="profile-label">CONTACT</p><a class="profile-email" href="mailto:<?= e($profile['email']) ?>"><?= e($profile['email']) ?> <span aria-hidden="true">↗</span></a>
        </section>
        <section class="profile-block tools" aria-labelledby="tools-title">
            <h3 id="tools-title"><span>02</span> TOOLS</h3><p class="profile-label">DESIGN TOOLS</p>
            <ul class="profile-tools"><?php foreach($profile['tools'] as $tool): ?><li><?= e($tool) ?></li><?php endforeach; ?></ul>
        </section>
        <section class="profile-block certificates" aria-labelledby="certificate-title">
            <h3 id="certificate-title"><span>03</span> CERTIFICATE</h3>
            <ul class="profile-certificates"><?php foreach($profile['certificates'] as $certificate): ?><li><?= e($certificate) ?></li><?php endforeach; ?></ul>
        </section>
    </div>
</section>
