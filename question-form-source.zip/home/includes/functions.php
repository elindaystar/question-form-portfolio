<?php
require_once __DIR__.'/project-data.php';
function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function asset($path) { return (defined('STATIC_EXPORT')?'':'dist/').$path; }
function route($page='index', $id='') {
    if(defined('STATIC_EXPORT') && $page==='project' && $id) return 'project-'.rawurlencode($id).'.html';
    return $page.(defined('STATIC_EXPORT')?'.html':'.php').($id ? '?id='.rawurlencode($id):'');
}
function visual($p) { ?>
    <div class="project-visual artwork" style="--art-ratio:<?= e($p['ratio']) ?>;--crop:<?= e($p['crop']) ?>">
        <img src="<?= asset('assets/projects/'.$p['image'].'.webp') ?>" alt="<?= e($p['alt']) ?>" width="<?= $p['width'] ?>" height="<?= $p['height'] ?>" loading="lazy" decoding="async">
    </div>
<?php }
function project_card($id,$p) { ?>
    <article class="project-card" data-category="<?= e($p['filter']) ?>">
        <a class="project-link" data-cursor="VIEW" href="<?= route('project',$id) ?>">
            <div class="project-meta"><span><?= e($p['number']) ?> / <?= e($p['category']) ?></span><span><?= e($p['type']) ?></span></div>
            <?php visual($p); ?>
            <div class="project-heading"><h3><?= e($p['title']) ?></h3><span aria-hidden="true">↗</span></div>
            <p><?= e($p['description']) ?></p>
        </a>
    </article>
<?php }
