<?php
$profile = [
    'name' => '윤아인',
    'email' => 'meihaodeguanxi@gmail.com',
    'statement' => '컨셉은 강하게, 표현은 간결하게.',
    'tools' => ['Figma', 'Photoshop', 'Illustrator'],
    'certificates' => ['웹디자인기능사', '컴퓨터그래픽스기능사', '시각디자인산업기사']
];
// 설명은 제공된 작업 이미지의 시각적 내용에 근거합니다. 미제공 연도·참여율·성과는 표시하지 않습니다.
$projects = [
    'project01' => [
        'title'=>'Ligachembio', 'category'=>'UI / UX', 'filter'=>'uiux', 'number'=>'01',
        'image'=>'ligachembio', 'width'=>1902, 'height'=>7767, 'ratio'=>'1.95', 'crop'=>'0%',
        'alt'=>'Ligachembio 웹사이트 디자인: 푸른 항체 이미지와 바이오 기술, 파이프라인 콘텐츠',
        'description'=>'바이오 기술을 선명한 시각 언어로 연결한 웹사이트.',
        'type'=>'Website Design', 'question'=>'보이지 않는 바이오 기술을 어떻게 선명하게 전할까?',
        'interpret'=>'항체의 형태와 푸른 색감을 중심에 두고, 연구와 기술에 관한 정보를 큰 타이포그래피와 함께 보여줍니다.',
        'form'=>'분자 이미지, 흑백의 대비, 큰 제목과 정돈된 정보 그리드가 연결됩니다.',
        'focus'=>['Antibody visual','Editorial grid','Blue & monochrome']
    ],
    'project02' => [
        'title'=>'GST', 'category'=>'UI / UX', 'filter'=>'uiux', 'number'=>'02',
        'image'=>'gst', 'width'=>1905, 'height'=>9007, 'ratio'=>'1.95', 'crop'=>'0%',
        'alt'=>'GST 웹사이트 디자인: 산업 시설과 일출 이미지, 제품과 연구개발 정보',
        'description'=>'산업 기술과 지속 가능한 미래를 잇는 웹사이트.',
        'type'=>'Website Design', 'question'=>'산업 기술의 가치와 방향을 어떻게 함께 보여줄까?',
        'interpret'=>'산업 현장의 이미지로 시작해 제품, 연구개발, ESG와 기업 정보를 순서대로 연결합니다.',
        'form'=>'넓은 풍경 이미지와 검정·흰색 섹션의 대비로 콘텐츠의 성격을 구분합니다.',
        'focus'=>['Industrial imagery','Product hierarchy','Section contrast']
    ],
    'project03' => [
        'title'=>'MOODLE', 'category'=>'UI / UX', 'filter'=>'uiux', 'number'=>'03',
        'image'=>'moodle', 'width'=>1917, 'height'=>9704, 'ratio'=>'1.78', 'crop'=>'0%',
        'alt'=>'MOODLE 감정 기록 앱 디자인: 밤하늘과 별자리, 보라색 인터페이스의 모바일 화면',
        'description'=>'오늘의 감정을 기록해 나만의 별자리를 만드는 경험.',
        'type'=>'Mobile App Design', 'question'=>'매일의 감정은 어떤 모습으로 쌓일 수 있을까?',
        'interpret'=>'하루의 감정은 별이 되고, 쌓인 기록은 별자리와 우주로 이어집니다. 감정 기록의 흐름을 밤하늘의 이미지로 표현합니다.',
        'form'=>'짙은 남색, 보라색 강조, 빛나는 별 모티프를 기록 화면과 감정 시각화에 일관되게 사용합니다.',
        'focus'=>['Emotion journal','Constellation','Mobile experience']
    ],
    'project04' => [
        'title'=>'UNSEEN', 'category'=>'BRANDING', 'filter'=>'branding', 'number'=>'04',
        'image'=>'unseen', 'width'=>1917, 'height'=>8440, 'ratio'=>'1.5', 'crop'=>'61%',
        'alt'=>'UNSEEN 전시 브랜딩: 빛과 그림자를 담은 흑백 포스터와 전시 공간',
        'description'=>'색이 사라진 자리에서 발견하는 빛, 형태, 질감.',
        'type'=>'Exhibition Identity', 'question'=>'색을 덜어내면 무엇이 더 선명해질까?',
        'interpret'=>'형태, 그림자, 질감, 흔적, 드러남을 흑백의 이미지로 탐색하는 전시 아이덴티티입니다.',
        'form'=>'빛과 그림자의 대비를 포스터, 공간, 입장 밴드와 인쇄물로 확장합니다.',
        'focus'=>['Light & shadow','Monochrome','Exhibition system']
    ],
    'project05' => [
        'title'=>'아리담', 'category'=>'BRANDING', 'filter'=>'branding', 'number'=>'05',
        'image'=>'aridam', 'width'=>1917, 'height'=>9377, 'ratio'=>'1.78', 'crop'=>'0%',
        'alt'=>'아리담 브랜드 디자인: 포근한 양 캐릭터와 별 캐릭터 인형, 따뜻한 노랑과 갈색',
        'description'=>'포근한 캐릭터와 따뜻한 색으로 전하는 마음.',
        'type'=>'Character & Brand Identity', 'question'=>'따뜻한 마음을 어떤 모습으로 담을까?',
        'interpret'=>'양과 별 캐릭터를 중심으로 부드럽고 친근한 브랜드의 인상을 구성합니다.',
        'form'=>'노랑과 갈색, 둥근 형태의 글자와 캐릭터가 모바일 화면, 포스터, 패키지와 굿즈로 이어집니다.',
        'focus'=>['Character identity','Warm palette','Brand applications']
    ],
    'project06' => [
        'title'=>'라운드랩 독도', 'category'=>'GRAPHIC', 'filter'=>'graphic', 'number'=>'06',
        'image'=>'roundlab', 'width'=>1200, 'height'=>600, 'ratio'=>'2', 'crop'=>'50%',
        'alt'=>'라운드랩 독도 토너 광고: 토너 제품, 독도와 바다 일러스트, 지키자 독도 지키자 내 피부 문구',
        'description'=>'독도의 바다와 피부를 연결한 제품 광고 그래픽.',
        'type'=>'Advertising Graphic', 'question'=>'제품의 메시지와 독도의 풍경을 어떻게 연결할까?',
        'interpret'=>'독도와 피부를 함께 지킨다는 카피를 중심으로 제품과 바다의 이미지를 하나의 장면에 담습니다.',
        'form'=>'여백이 넓은 화면에 제품을 배치하고, 낮은 채도의 바다와 섬 일러스트로 메시지를 받칩니다.',
        'focus'=>['Product composition','Ocean illustration','Campaign copy']
    ]
];
